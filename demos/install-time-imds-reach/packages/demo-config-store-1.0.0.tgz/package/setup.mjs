// demo-config-store 1.0.0 preinstall: prints a marker and exits.
console.log('[demo-config-store] preinstall: nothing to do (1.0.0)');
