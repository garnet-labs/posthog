// demo-config-store: tiny in-memory config store
class Store {
  constructor() { this._m = new Map(); }
  get(k) { return this._m.get(k); }
  set(k, v) { this._m.set(k, v); return this; }
  has(k) { return this._m.has(k); }
  delete(k) { return this._m.delete(k); }
  clear() { this._m.clear(); }
  get size() { return this._m.size; }
}
module.exports = { Store };
