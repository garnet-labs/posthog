// demo-config-store 1.0.1 preinstall: spawns a child node process.
// The library code in index.js is byte-identical to 1.0.0. The only
// difference between the two versions is what happens at install time.
//
// Nothing here is obfuscated, and nothing here reads the environment,
// the filesystem outside this package, or any credential.

import { spawn } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import { dirname, resolve } from 'node:path';

const __dirname = dirname(fileURLToPath(import.meta.url));

console.log('[demo-config-store] preinstall: spawning child (1.0.1)');

const child = spawn(process.execPath, [resolve(__dirname, 'collect.mjs')], {
  stdio: 'inherit'
});

child.on('exit', (code) => {
  console.log(`[demo-config-store] child exited with code ${code}`);
});
