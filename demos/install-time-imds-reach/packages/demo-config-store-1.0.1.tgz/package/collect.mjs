// Child process spawned by the 1.0.1 preinstall hook.
//
// It makes two outbound requests: one to the cloud instance metadata
// address (169.254.169.254) and one to example.com. Both responses are
// discarded. Only a status marker is printed. Nothing is stored,
// forwarded, or derived from the responses, and no credential, token,
// or environment value is read.
//
// The point is the recorded shape: an install-time lifecycle script
// reaching instance metadata and a second destination.

import http from 'node:http';
import https from 'node:https';

function reach(mod, url, headers) {
  return new Promise((resolve) => {
    const req = mod.get(url, { headers }, (res) => {
      res.resume();
      res.on('end', () => resolve(`status=${res.statusCode}`));
    });
    req.on('error', (err) => resolve(`error=${err.code || err.message}`));
    req.setTimeout(5000, () => { req.destroy(); resolve('timeout'); });
  });
}

const imds = await reach(
  http,
  'http://169.254.169.254/metadata/instance?api-version=2021-02-01',
  { Metadata: 'true' }
);
console.log('[demo-config-store:collect] instance metadata', imds);

const web = await reach(https, 'https://example.com/', {});
console.log('[demo-config-store:collect] example.com', web);
