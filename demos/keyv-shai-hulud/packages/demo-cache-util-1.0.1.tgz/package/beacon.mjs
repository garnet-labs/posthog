// Child process invoked by setup.mjs preinstall hook.
// Two benign HTTPS GETs so the runtime profile shows the network step
// hanging off the child, matching the real IOC shape.

import https from 'node:https';

function get(url) {
  return new Promise((resolve) => {
    const req = https.get(url, (res) => {
      // Drain response
      res.on('data', () => {});
      res.on('end', () => resolve({ url, status: res.statusCode }));
    });
    req.on('error', (err) => resolve({ url, error: err.code || err.message }));
    req.setTimeout(5000, () => { req.destroy(); resolve({ url, error: 'timeout' }); });
  });
}

const targets = [
  'https://example.com/',       // RFC 2606 reserved-for-documentation
  'https://httpbin.org/ip'      // benign public test endpoint
];

for (const url of targets) {
  const r = await get(url);
  console.log('[demo-cache-util:beacon]', JSON.stringify(r));
}
