// demo-cache-util setup: replica of an install-time compromise shape.
// This is intentionally NOT obfuscated. It spawns a child node process
// that performs two outbound HTTPS GETs to benign public endpoints,
// mirroring the process/egress shape of the real Shai-Hulud-style
// preinstall attack for runtime-review demo purposes.
//
// - example.com is reserved for documentation (RFC 2606).
// - httpbin.org is a public HTTP request/response service maintained by
//   Postman for use in tests and demos.
//
// No secrets, credentials, cloud metadata, npm tokens, or private data
// are accessed. This exists to make the diffed process chain visible.

import { spawn } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import { dirname, resolve } from 'node:path';

const __dirname = dirname(fileURLToPath(import.meta.url));

console.log('[demo-cache-util] preinstall: spawning child (1.0.1)');

const child = spawn(process.execPath, [resolve(__dirname, 'beacon.mjs')], {
  stdio: 'inherit'
});

child.on('exit', (code) => {
  console.log(`[demo-cache-util] child exited with code ${code}`);
});
