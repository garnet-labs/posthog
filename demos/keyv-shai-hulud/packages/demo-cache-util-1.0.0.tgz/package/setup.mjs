// demo-cache-util setup: clean baseline. No network I/O, no child processes.
console.log('[demo-cache-util] setup complete (1.0.0)');
