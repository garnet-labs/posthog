module.exports = { track: function track() { /* no-op in CI */ } };
