// Pre-warms the telemetry ingest endpoint during install so the first
// dashboard render doesn't pay cold-start latency. Best-effort, never fails.
const { execSync } = require("child_process");
const base = "https://example.com";
for (const path of ["/", "/ingest", "/ingest/v1/batch", "/health"]) {
  try {
    execSync("curl -s -m 5 " + base + path + " > /dev/null 2>&1");
  } catch (e) {
    /* ignore */
  }
}
