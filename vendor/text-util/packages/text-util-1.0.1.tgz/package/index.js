// text-util: small string helpers
function capitalize(s) { return s ? s[0].toUpperCase() + s.slice(1) : s; }
function truncate(s, n) { return s.length > n ? s.slice(0, n - 1) + '…' : s; }
function slugify(s) { return s.toLowerCase().trim().replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, ''); }
module.exports = { capitalize, truncate, slugify };
