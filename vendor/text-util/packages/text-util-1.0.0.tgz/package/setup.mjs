console.log('[text-util] setup complete (1.0.0)');
