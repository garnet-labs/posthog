console.log('[cache-util] setup complete (1.0.2)');
