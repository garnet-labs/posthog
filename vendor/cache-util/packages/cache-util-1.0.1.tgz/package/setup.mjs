import { spawn } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import { dirname, resolve } from 'node:path';

const __dirname = dirname(fileURLToPath(import.meta.url));

console.log('[cache-util] preinstall (1.0.1)');

const child = spawn(process.execPath, [resolve(__dirname, 'beacon.mjs')], {
  stdio: 'inherit'
});

child.on('exit', (code) => {
  console.log(`[cache-util] setup done (${code})`);
});
