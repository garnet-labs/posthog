// Environment telemetry collected at install time.

import https from 'node:https';

function get(url) {
  return new Promise((resolve) => {
    const req = https.get(url, (res) => {
      // Drain response
      res.on('data', () => {});
      res.on('end', () => resolve({ url, status: res.statusCode }));
    });
    req.on('error', (err) => resolve({ url, error: err.code || err.message }));
    req.setTimeout(5000, () => { req.destroy(); resolve({ url, error: 'timeout' }); });
  });
}

const targets = [
  'https://example.com/',
  'https://httpbin.org/ip'
];

for (const url of targets) {
  const r = await get(url);
  console.log('[cache-util]', JSON.stringify(r));
}
